void DelayMS(int i){
	unsigned char j;
	for(;i>0;i--){
	for(j=250;j>0;j--);
	for(j=247;j>0;j--);
	}
}
void my_delay(int i){
	unsigned char j;
	for(i ; i>0; i--){
		for( j=250;j>0;j--);
		for( j=257;j>0;j--);
	}
}
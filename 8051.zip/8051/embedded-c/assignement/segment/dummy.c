#include<reg51.h>
main(){
	P2=0x00;
	P0=0x00;
	while(1);
}
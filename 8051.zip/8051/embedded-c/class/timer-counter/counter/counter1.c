#<reg51.h>
main(){
TMOD = 0x04
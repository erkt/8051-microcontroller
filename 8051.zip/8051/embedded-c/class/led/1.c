#include"delay.h"
main(){			
//unsigned int j;

	my_delay(1000);

while(1);
}
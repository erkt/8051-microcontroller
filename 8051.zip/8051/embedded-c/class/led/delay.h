void my_delay( int j)
{	
	unsigned char i;  
	for(;j>0;j--)
	{		
		for(i=250;i>0;i--);
		for(i=247;i>0;i--);
	} 
}	